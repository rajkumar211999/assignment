package com.dealsandcouponsApp.coupons.exception;

public class CouponsNotFoundException extends RuntimeException {
	public  CouponsNotFoundException(String message) {
		super(message);
	}
}
