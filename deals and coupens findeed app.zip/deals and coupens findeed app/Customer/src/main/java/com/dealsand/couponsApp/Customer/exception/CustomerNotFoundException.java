package com.dealsand.couponsApp.Customer.exception;

public class CustomerNotFoundException extends RuntimeException{
	public  CustomerNotFoundException(String message) {
		super(message);
	}

}
